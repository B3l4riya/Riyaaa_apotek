<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Apotek extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Apotek_m');
    }

    public function index()
    {
        $data['apotek'] = $this->Apotek_m->get_all();
        $this->load->view('apotek', $data);
    }

    public function tambah()
    {
        $this->load->view('tambah');
    }

    public function tambah_aksi()
    {
        $nama_obat = $this->input->post('Nama_obat');
        $harga = $this->input->post('Harga');
        $satuan = $this->input->post('Satuan');
        $stok = $this->input->post('Stok');

        $data = array(
            'Nama_obat' => $nama_obat,
            'Harga' => $harga,
            'Satuan' => $satuan,
            'Stok' => $stok
        );

        $this->Apotek_m->insert_obat($data);
        redirect('index.php/apotek');
    }

    public function edit($id)
    {
        $data['apotek'] = $this->Apotek_m->get_by_id($id);
        $this->load->view('edit', $data);
    }

    public function edit_aksi()
    {
        $id_obat = $this->input->post('Id_obat');
        $nama_obat = $this->input->post('Nama_obat');
        $harga = $this->input->post('Harga');
        $satuan = $this->input->post('Satuan');
        $stok = $this->input->post('Stok');

        $data = array(
            'Nama_obat' => $nama_obat,
            'Harga' => $harga,
            'Satuan' => $satuan,
            'Stok' => $stok
        );

        $this->Apotek_m->update_obat($id_obat, $data);
        redirect('index.php/apotek');
    }

    public function hapus($id)
    {
        $this->Apotek_m->delete_obat($id);
        redirect('index.php/apotek');
    }
}