<div class="content-wrapper">
<a clas="fas fa-bel fa-fw"></i>
<span class="badge-dadger badge-couter">3+</span>
</a>
<div class"dropdown-list dropdown-menu-right shadow animated--grow-in
"aria-labelledy="alertsDropdown">
</h6 class="dropdown-header>
Alerts Center
</6>
<a class="dropdown-item d-flex align-items-center" href="a">
</div>