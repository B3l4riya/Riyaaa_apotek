<?php $this->load->view('templates/header'); ?>
<?php $this->load->view('templates/sidebar'); ?>
<div class="container-fluid" id="container-wrapper">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Data Obat</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="">Home</a></li>
              <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
            </ol>
          </div>
 </div>
<div class="main-panel">
    <div class="content">
        <div class="container-fluid">
            <h4 class="page-title"></h4>
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title"></h5>
                            <a href="<?php echo base_url('index.php/apotek/tambah'); ?>" class="btn btn-primary mb-3">Tambah Obat</a>
                            <div class="table-responsive" style="overflow-x: auto;">
                                <table class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th>ID Obat</th>
                                            <th>Nama Obat</th>
                                            <th>Harga</th>
                                            <th>Satuan</th>
                                            <th>Stok</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (empty($apotek)): ?>
                                            <tr><td colspan="6">Tidak ada data obat.</td></tr>
                                        <?php else: ?>
                                            <?php foreach ($apotek as $row): ?>
                                                <tr>
                                                    <td><?php echo $row['Id_obat']; ?></td>
                                                    <td><?php echo $row['Nama_obat']; ?></td>
                                                    <td>Rp <?php echo number_format($row['Harga'], 0, ',', '.'); ?></td>
                                                    <td><?php echo $row['Satuan']; ?></td>
                                                    <td><?php echo $row['Stok']; ?></td>
                                                    <td>
                                                        <a href="<?php echo site_url('index.php/apotek/edit/' . $row['Id_obat']); ?>">Edit</a> |
                                                        <a href="<?php echo site_url('index.php/apotek/hapus/' . $row['Id_obat']); ?>" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">Hapus</a>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
 </div>
 </div>
 </div>
<?php $this->load->view('templates/footer'); ?>