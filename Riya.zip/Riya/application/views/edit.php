<?php $this->load->view('templates/header'); ?>
<?php $this->load->view('templates/sidebar'); ?>

<div class="main-panel">
    <div class="content">
        <div class="container-fluid">
            <h4 class="page-title">Edit Data Obat</h4>
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title"></h5>
                            <form action="<?php echo site_url('index.php/apotek/edit_aksi'); ?>" method="POST">
                                <input type="hidden" name="Id_obat" value="<?php echo $apotek['Id_obat']; ?>">
                                <div class="mb-3">
                                    <label for="Nama_obat" class="form-label">Nama Obat</label>
                                    <input type="text" class="form-control" id="Nama_obat" name="Nama_obat" value="<?php echo $apotek['Nama_obat']; ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label for="Harga" class="form-label">Harga</label>
                                    <input type="number" class="form-control" id="Harga" name="Harga" value="<?php echo $apotek['Harga']; ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label for="Satuan" class="form-label">Satuan</label>
                                    <input type="text" class="form-control" id="Satuan" name="Satuan" value="<?php echo $apotek['Satuan']; ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label for="Stok" class="form-label">Stok</label>
                                    <input type="number" class="form-control" id="Stok" name="Stok" value="<?php echo $apotek['Stok']; ?>" required>
                                </div>
                                <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                                <a href="<?php echo site_url('apotek'); ?>" class="btn btn-secondary">Batal</a>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  </div>
</div>
<?php $this->load->view('templates/footer'); ?>