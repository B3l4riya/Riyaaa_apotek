<?php $this->load->view('templates/header'); ?>
<?php $this->load->view('templates/sidebar'); ?>
<div class="container-fluid" id="container-wrapper">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Tambah Data Obat</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="">Home</a></li>
              <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
            </ol>
          </div>
<div class="main-panel">
    <div class="content">
        <div class="container-fluid">
            <h4 class="page-title"></h4>
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title"></h5>
                            <form action="<?php echo base_url('index.php/apotek/tambah_aksi'); ?>" method="POST">
                                <div class="mb-3">
                                    <label for="Nama_obat" class="form-label">Nama Obat</label>
                                    <input type="text" class="form-control" id="Nama_obat" name="Nama_obat" required>
                                </div>
                                <div class="mb-3">
                                    <label for="Harga" class="form-label">Harga</label>
                                    <input type="number" class="form-control" id="Harga" name="Harga" required>
                                </div>
                                <div class="mb-3">
                                    <label for="Satuan" class="form-label">Satuan</label>
                                    <input type="text" class="form-control" id="Satuan" name="Satuan" required>
                                </div>
                                <div class="mb-3">
                                    <label for="Stok" class="form-label">Stok</label>
                                    <input type="number" class="form-control" id="Stok" name="Stok" required>
                                </div>
                                <button type="submit" class="btn btn-primary">Simpan</button>
                                <a href="<?php echo site_url('apotek'); ?>" class="btn btn-secondary">Batal</a>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</div>
<?php $this->load->view('templates/footer'); ?>