<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Apotek_m extends CI_Model {

    private $table = 'apotek';
    private $primary_key = 'Id_obat';

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function get_all()
    {
        return $this->db->get($this->table)->result_array();
    }

    public function insert_obat($data)
    {
        return $this->db->insert($this->table, $data);
    }

    public function get_by_id($id)
    {
        return $this->db->get_where($this->table, [$this->primary_key => $id])->row_array();
    }

    public function update_obat($id, $data)
    {
        $this->db->where($this->primary_key, $id);
        return $this->db->update($this->table, $data);
    }

    public function delete_obat($id)
    {
        $this->db->where($this->primary_key, $id);
        $this->db->delete($this->table);
        // Periksa apakah tabel sekarang kosong
        if ($this->db->count_all($this->table) == 0) {
            $this->reset_autoincrement();
        }
    }

    public function reset_autoincrement()
    {
        $this->db->query("ALTER TABLE " . $this->table . " AUTO_INCREMENT = 1");
    }
}